/* Teapot PoC Prototype StateMachine BLE communication example. 
   Control video playback with microbit gesture input.

video attribute (CC license): 
Sweet potato sprouting timelapse 60fps HD by Evgen Khivrenko
https://www.youtube.com/watch?v=LcixBmtvddo&feature=emb_title

*/

// Teapot Object
let jar = {
  state: "sleep",
}

// Plant Object
let mimic = {
  state: "start",
  alertsfxfile: 'videos/SproutHalf.webm',
  winsfxfile: 'asd',
  losesfxfile: 'asd',
  sleepbgmfile: 'asd',
  alertbgmfile: 'asd',
  winbgmfile: 'asd',
  losebgmfile: 'asd',

  alertsfx: "",
  winsfx: "",
  losesfx: "",
  sleepbgm: "",
  alertbgm: "",
  winbgm: "",
  losebgm: "",
  
  bgmlist: [],
  
  loadAssets: function() {
    this.alertsfx = loadSound(this.alertsfxfile, isLoaded);
    this.winsfx = loadSound(this.winsfxfile, isLoaded);
    this.losesfx = loadSound(this.losesfxfile, isLoaded);
    this.sleepbgm = loadSound(this.sleepbgmfile, isLoaded);
    this.alertbgm = loadSound(this.alertbgmfile, isLoaded);
    this.winbgm = loadSound(this.winbgmfile, isLoaded);
    this.losebgm = loadSound(this.losebgmfile, isLoaded);
    
    bgmlist = [sleepbgm, alertbgm, winbgm, losebgm];
  },
  draw: function() {
    let scaleAdj = 1.5;
    let offset = 200;
    if (this.state === "Start" || this.state == "End") {} 
    else{
      imageMode(CENTER);
      image(this.video, displayWidth/2+100, displayHeight/2+offset, 1280*scaleAdj, 720*scaleAdj);
      
    }
  },
  reset: function() {
    this.state = "start";
    for (let bgmname of bgmlist){
      bgmname.stop();
      bgmname.loop();
      bgmname.pause();
    }
  },
  sleep: function() {
    this.state = "sleep";
    for (let bgmname of bgmlist){
      bgmname.pause();
    }
    this.sleepbgm.play();
  },
  alert: function() {
    this.state = "alert";
    this.alertsfx.play();
    for (let bgmname of bgmlist){
      bgmname.pause();
    }
    this.alertbgm.play();
  },
  win: function() {
    this.state = "win";
    this.winsfx.play();
    for (let bgmname of bgmlist){
      bgmname.pause();
    }
    this.winbgm.play();
  },
  lose: function() {
    this.state = "lose";
    this.losesfx.play();
    for (let bgmname of bgmlist){
      bgmname.pause();
    }
    this.losebgm.play();
  }
  //activate air pump or etc.
}


function preload() {
  // specify multiple formats for different browsers
  mimic.loadAssets();

}

function setup() {
  //createCanvas(800, 600);
  createCanvas(700,1230);

  const connectButton = createButton("Connect");
  connectButton.mousePressed(connectButtonPressed);

  const disconnectButton = createButton("Disconnect");
  disconnectButton.mousePressed(disconnectButtonPressed);

  playButton = createButton('play');

  playButton.mousePressed(toggleVid); // attach button listener

  //video.showControls();
}

function draw() {
  background(0);

  //draw the plant object
  mimic.draw();
}

function handleData(status) {

  if (jar.state !== status) { //check if status is different from previous

    if (status === "start") {
      plant.reset(); 
    } else if (status === "sleep") {
      plant.sleep();
    } else if (status === "alert") {
      plant.alert();
    }
    else if (status === "win") {
      plant.win();
    }
    else if (status === "lose") {
      plant.lose();
    }

    print("update state:" + status);

    jar.state = status; //update the status
  }

}

function videoLoaded() {
  plant.video.hide();
  
  plant.video.onended(plant.end());
  
  
  slider = createSlider(0, plant.video.duration(), 0, 0.01);
  slider.input(seekVid);
  slider.style("width", "610px");
}


// Slider & Button UI
let isPlaying = false;
let playButton;
let slider;

// plays or pauses the video depending on current state
function toggleVid() {
  if (isPlaying) {
    plant.video.pause();
    playButton.html('play');
  } else {
    plant.video.play();
    playButton.html('pause');
  }
  isPlaying = !isPlaying;
}


function seekVid() {
  let val = slider.value();
  print(val);
  plant.video.time(val);
}




function keyPressed() {
  if (keyCode === 32) { //press SPACE BAR to turn on fullscreen.
    toggleFullScreen();
  }
}


function toggleFullScreen() {
  let fs = fullscreen();
  fullscreen(!fs);
}